public class InfoActivity {
}
