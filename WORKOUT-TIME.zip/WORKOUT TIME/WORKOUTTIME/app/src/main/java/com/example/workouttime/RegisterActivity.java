package com.example.workouttime;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_register);


        TextView btn = findViewById (R.id.AlreadyHaveAnAccount);
        btn.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick( View view ) {
                startActivity (new Intent (RegisterActivity.this , LoginActivity.class));
            }
        });
    }
        public void go_to( View view ) {
            Intent i;
            i = new Intent (this , InfoActivity.class);
            startActivity (i);
        }


}
