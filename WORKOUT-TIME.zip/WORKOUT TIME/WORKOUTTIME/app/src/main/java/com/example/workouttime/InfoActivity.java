package com.example.workouttime;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class InfoActivity extends AppCompatActivity {
    Button a;
    Button work;
    Button ph;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        a =findViewById(R.id.button);
      a.setOnClickListener(view -> startActivity(new Intent(InfoActivity.this,MainActivity.class)));

        work = findViewById (R.id.work);
        work.setOnLongClickListener (new View.OnLongClickListener () {
            @Override
            public boolean onLongClick( View view ) {
                Toast.makeText (InfoActivity.this , "Welcome to the Planet app,\n" +
                        "We are happy to serve you\n" +
                        "From Saturday to Thursday from 9 am to 11 pm\n" +
                        "Friday from 4 pm to 11 pm" , Toast.LENGTH_SHORT).show ();
                return false;
            }
        });

        work.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick( View view ) {
                Toast.makeText (InfoActivity.this , "Please click and hold" , Toast.LENGTH_SHORT).show ();

            }
        });


        Button ph = ( Button ) findViewById (R.id.cal);
        ph.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick( View view ) {
                Intent i = new Intent (android.content.Intent.ACTION_VIEW , Uri.parse ("tel:0555555555"));
                startActivity (i);
            }
        });


}

}